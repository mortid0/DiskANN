/*
 * Copyright (c) Microsoft Corporation.
 * Licensed under the MIT license.
 */

//! Native build, durable-update, reopen and compaction experiment.
//!
//! Arguments are `--name value` pairs. `--action all` builds an index, benchmarks
//! its natural prepared workload, then exercises updates and compaction. The
//! update scenario uses a new label and rows outside every queried natural label,
//! preserving the supplied natural ground truth. A separate probe workload has
//! independently recomputed integer squared-L2 ground truth for changed records.

use std::{
    collections::{BTreeMap, BTreeSet, HashMap},
    fs::{File, OpenOptions},
    io::{BufRead, BufReader, Read, Write},
    path::{Path, PathBuf},
    sync::{
        atomic::{AtomicUsize, Ordering},
        Barrier,
    },
    time::Instant,
};

use anyhow::{ensure, Context, Result};
use diskann_disk::{
    build::filtered::StitchedBuildConfig,
    filtered::{
        updates::{DeltaLimits, Mutation},
        FilteredHit, FilteredIndex, FilteredIndexConfig, FilteredSnapshot,
    },
};
use diskann_utils::views::rowmajor;
use serde_json::{json, Value};

struct Args(HashMap<String, String>);

impl Args {
    fn parse() -> Result<Self> {
        let values: Vec<_> = std::env::args().skip(1).collect();
        ensure!(
            values.len().is_multiple_of(2),
            "arguments must be --name value pairs"
        );
        let mut args = HashMap::new();
        for pair in values.chunks_exact(2) {
            ensure!(pair[0].starts_with("--"), "expected --name argument");
            ensure!(
                args.insert(pair[0][2..].to_owned(), pair[1].clone())
                    .is_none(),
                "duplicate argument {}",
                pair[0]
            );
        }
        Ok(Self(args))
    }

    fn value(&self, name: &str, default: &str) -> String {
        self.0
            .get(name)
            .cloned()
            .unwrap_or_else(|| default.to_owned())
    }

    fn required(&self, name: &str) -> Result<PathBuf> {
        Ok(PathBuf::from(
            self.0
                .get(name)
                .with_context(|| format!("--{name} required"))?,
        ))
    }
}

fn header(path: &Path) -> Result<(usize, usize)> {
    let mut bytes = [0; 8];
    File::open(path)?.read_exact(&mut bytes)?;
    Ok((
        u32::from_le_bytes(bytes[..4].try_into()?) as usize,
        u32::from_le_bytes(bytes[4..].try_into()?) as usize,
    ))
}

fn matrix_u8(path: &Path) -> Result<(usize, usize, Vec<u8>)> {
    let (rows, dimensions) = header(path)?;
    let count = rows
        .checked_mul(dimensions)
        .context("matrix dimensions overflow")?;
    let mut file = File::open(path)?;
    ensure!(
        file.metadata()?.len() == 8 + count as u64,
        "invalid uint8 matrix size: {}",
        path.display()
    );
    file.read_exact(&mut [0; 8])?;
    let mut values = vec![0; count];
    file.read_exact(&mut values)?;
    Ok((rows, dimensions, values))
}

fn matrix_u32(path: &Path) -> Result<(usize, usize, Vec<u32>)> {
    let (rows, columns) = header(path)?;
    let bytes = std::fs::read(path)?;
    ensure!(
        bytes.len() == 8 + rows * columns * 4,
        "invalid uint32 matrix size: {}",
        path.display()
    );
    let values = bytes[8..]
        .chunks_exact(4)
        .map(|x| u32::from_le_bytes(x.try_into().expect("four-byte chunk")))
        .collect();
    Ok((rows, columns, values))
}

fn read_postings(path: &Path, rows: usize, skip: Option<u32>) -> Result<BTreeMap<u32, Vec<u32>>> {
    let mut postings = BTreeMap::<u32, Vec<u32>>::new();
    let mut count = 0;
    for line in BufReader::new(File::open(path)?).lines() {
        let line = line?;
        ensure!(count < rows, "more label rows than base vectors");
        let mut labels = BTreeSet::new();
        for token in line
            .split([',', ' ', '\t'])
            .filter(|token| !token.is_empty())
        {
            let label = token.parse::<u32>()?;
            if Some(label) != skip {
                labels.insert(label);
            }
        }
        for label in labels {
            postings.entry(label).or_default().push(count as u32);
        }
        count += 1;
    }
    ensure!(count == rows, "label row count differs from base vectors");
    Ok(postings)
}

#[derive(Clone)]
struct Query {
    vector: Vec<u8>,
    label: u32,
    truth: Vec<u32>,
}

struct Workload {
    queries: Vec<Query>,
    postings: BTreeMap<u32, Vec<u32>>,
    k: usize,
    dimensions: usize,
    identity: String,
}

fn load_workload(prepared: &Path, limit: usize) -> Result<Workload> {
    let (rows, dimensions, vectors) = matrix_u8(&prepared.join("query.u8bin"))?;
    let (label_rows, label_width, labels) = matrix_u32(&prepared.join("query_labels.u32bin"))?;
    let truth_path = prepared.join("groundtruth.bin");
    let (truth_rows, k) = header(&truth_path)?;
    let truth_bytes = std::fs::read(truth_path)?;
    ensure!(
        rows == label_rows && label_width == 1 && rows == truth_rows && k > 0,
        "prepared query/label/truth shapes differ"
    );
    ensure!(
        truth_bytes.len() == 8 + rows * k * 8,
        "ground truth must contain IDs and distances"
    );
    let queries: Vec<_> = (0..rows.min(limit))
        .map(|i| Query {
            vector: vectors[i * dimensions..(i + 1) * dimensions].to_vec(),
            label: labels[i],
            truth: (0..k)
                .map(|j| {
                    let offset = 8 + (i * k + j) * 4;
                    u32::from_le_bytes(
                        truth_bytes[offset..offset + 4]
                            .try_into()
                            .expect("four-byte truth ID"),
                    )
                })
                .collect(),
        })
        .collect();
    ensure!(!queries.is_empty(), "query workload is empty");
    let mut postings = BTreeMap::new();
    for label in queries.iter().map(|q| q.label).collect::<BTreeSet<_>>() {
        let (n, width, ids) = matrix_u32(&prepared.join(format!("label_{label}.u32bin")))?;
        ensure!(
            width == 1 && ids.len() == n && ids.windows(2).all(|w| w[0] < w[1]),
            "invalid label postings"
        );
        postings.insert(label, ids);
    }
    let manifest_path = prepared.join("manifest.json");
    let identity = if manifest_path.exists() {
        let manifest: Value = serde_json::from_slice(&std::fs::read(manifest_path)?)?;
        [
            "query.u8bin",
            "query_labels.u32bin",
            "groundtruth.bin",
            "labels.txt",
        ]
        .iter()
        .map(|name| {
            manifest["artifacts"][name]["sha256"]
                .as_str()
                .context("missing prepared hash")
                .map(str::to_owned)
        })
        .collect::<Result<Vec<_>>>()?
        .join(":")
    } else {
        format!("unmanifested:{}", prepared.canonicalize()?.display())
    };
    Ok(Workload {
        queries,
        postings,
        k,
        dimensions,
        identity,
    })
}

fn emit(output: &mut File, row: Value) -> Result<()> {
    writeln!(output, "{row}")?;
    output.flush()?;
    Ok(())
}

struct Observation {
    query: usize,
    hits: Vec<FilteredHit>,
    micros: f64,
    sequence: u64,
    exact_fallback: bool,
    base_searches: usize,
    delta_candidates: usize,
}

fn benchmark(
    snapshot: &FilteredSnapshot<u8>,
    workload: &Workload,
    args: &Args,
    phase: &str,
    output: &mut File,
) -> Result<()> {
    let threads: Vec<usize> = args
        .value("query-threads", &args.value("threads", "8"))
        .split(',')
        .map(str::parse)
        .collect::<std::result::Result<_, _>>()?;
    let breadths: Vec<u32> = args
        .value("l", "60,144")
        .split(',')
        .map(str::parse)
        .collect::<std::result::Result<_, _>>()?;
    let repeats: usize = args.value("reps", "3").parse()?;
    let authoritative: bool = args.value("timing-authoritative", "false").parse()?;
    ensure!(
        repeats > 0
            && threads.iter().all(|&n| n > 0)
            && breadths.iter().all(|&l| l as usize >= workload.k),
        "positive threads/repeats and L >= K required"
    );
    for &threads in &threads {
        for &l in &breadths {
            for repeat in 0..repeats {
                let warmup_next = AtomicUsize::new(0);
                let measured_next = AtomicUsize::new(0);
                let ready = Barrier::new(threads + 1);
                let start = Barrier::new(threads + 1);
                let (mut observations, elapsed) = std::thread::scope(|scope| -> Result<_> {
                    let workers: Vec<_> = (0..threads)
                        .map(|_| {
                            scope.spawn(|| -> Result<Vec<Observation>> {
                                let mut observed =
                                    Vec::with_capacity(workload.queries.len().div_ceil(threads));
                                let warmup = (|| -> Result<()> {
                                    loop {
                                        let query = warmup_next.fetch_add(1, Ordering::Relaxed);
                                        let Some(query) = workload.queries.get(query) else {
                                            break;
                                        };
                                        snapshot.search(
                                            &query.vector,
                                            query.label,
                                            workload.k,
                                            l,
                                        )?;
                                    }
                                    Ok(())
                                })();
                                ready.wait();
                                start.wait();
                                warmup?;
                                loop {
                                    let query_index = measured_next.fetch_add(1, Ordering::Relaxed);
                                    let Some(query) = workload.queries.get(query_index) else {
                                        break;
                                    };
                                    let before = Instant::now();
                                    let found = snapshot.search(
                                        &query.vector,
                                        query.label,
                                        workload.k,
                                        l,
                                    )?;
                                    let micros = before.elapsed().as_secs_f64() * 1e6;
                                    observed.push(Observation {
                                        query: query_index,
                                        hits: found.hits,
                                        micros,
                                        sequence: found.sequence,
                                        exact_fallback: found.exact_fallback,
                                        base_searches: found.base_searches,
                                        delta_candidates: found.delta_candidates,
                                    });
                                }
                                Ok(observed)
                            })
                        })
                        .collect();
                    ready.wait();
                    let begin = Instant::now();
                    start.wait();
                    let mut observed = Vec::with_capacity(workload.queries.len());
                    for worker in workers {
                        observed.extend(
                            worker
                                .join()
                                .map_err(|_| anyhow::anyhow!("query worker panicked"))??,
                        );
                    }
                    Ok((observed, begin.elapsed()))
                })?;
                observations.sort_unstable_by_key(|x| x.query);
                ensure!(
                    observations.len() == workload.queries.len(),
                    "incomplete measured workload"
                );
                let mut violations = 0;
                let mut duplicates = 0;
                let mut short = 0;
                let mut hits = 0;
                let mut by_label = BTreeMap::<u32, (usize, usize, Vec<f64>)>::new();
                for (i, observation) in observations.iter().enumerate() {
                    let query = &workload.queries[i];
                    ensure!(
                        observation.query == i && observation.sequence == snapshot.sequence(),
                        "inconsistent query snapshot"
                    );
                    let ids: BTreeSet<_> = observation.hits.iter().map(|h| h.id).collect();
                    duplicates += observation.hits.len() - ids.len();
                    short += usize::from(observation.hits.len() < workload.k);
                    violations += ids
                        .iter()
                        .filter(|id| workload.postings[&query.label].binary_search(id).is_err())
                        .count();
                    let correct = query.truth.iter().filter(|id| ids.contains(id)).count();
                    hits += correct;
                    let entry = by_label.entry(query.label).or_default();
                    entry.0 += 1;
                    entry.1 += correct;
                    entry.2.push(observation.micros);
                }
                let mut latencies: Vec<_> = observations.iter().map(|o| o.micros).collect();
                latencies.sort_unstable_by(f64::total_cmp);
                let percentile =
                    |p: f64| latencies[(latencies.len() as f64 * p).ceil() as usize - 1];
                let labels: Vec<_> = by_label.into_iter().map(|(label, (queries, hits, mut latencies))| {
                    latencies.sort_unstable_by(f64::total_cmp);
                    json!({"label":label,"queries":queries,"recall":hits as f64/(queries*workload.k) as f64,
                        "mean_us":latencies.iter().sum::<f64>()/queries as f64,
                        "p95_us":latencies[(queries as f64*0.95).ceil() as usize-1]})
                }).collect();
                emit(
                    output,
                    json!({"kind":"query","implementation":"rust_native_lifecycle","phase":phase,
                    "sequence":snapshot.sequence(),"queries":observations.len(),"warmup_queries":observations.len(),
                    "threads":threads,"l":l,"k":workload.k,"repeat":repeat,"prepared_identity":workload.identity,
                    "timing_authoritative":authoritative,"latency_contract":"public_snapshot_search_call",
                    "qps":observations.len() as f64/elapsed.as_secs_f64(),"wall_seconds":elapsed.as_secs_f64(),
                    "mean_us":latencies.iter().sum::<f64>()/latencies.len() as f64,
                    "p50_us":percentile(0.5),"p95_us":percentile(0.95),"p99_us":percentile(0.99),
                    "recall":hits as f64/(observations.len()*workload.k) as f64,"strict_id_recall":true,
                    "filter_violations":violations,"duplicate_results":duplicates,"short_results":short,
                    "exact_fallback_queries":observations.iter().filter(|o| o.exact_fallback).count(),
                    "base_searches":observations.iter().map(|o| o.base_searches).sum::<usize>(),
                    "delta_candidates":observations.iter().map(|o| o.delta_candidates).sum::<usize>(),"labels":labels}),
                )?;
                ensure!(
                    violations == 0 && duplicates == 0 && short == 0,
                    "invalid or incomplete filtered results in {phase}"
                );
            }
        }
    }
    Ok(())
}

fn exact_l2(left: &[u8], right: &[u8]) -> u64 {
    left.iter()
        .zip(right)
        .map(|(&a, &b)| {
            let d = i64::from(a) - i64::from(b);
            (d * d) as u64
        })
        .sum()
}

struct Scenario {
    mutations: Vec<Mutation<u8>>,
    before: BTreeMap<u32, (Vec<u8>, Vec<u32>)>,
    live: BTreeMap<u32, Vec<u8>>,
    deleted: Vec<u32>,
    label: u32,
    dimensions: usize,
}

fn scenario(
    snapshot: &FilteredSnapshot<u8>,
    workload: &Workload,
    rows: usize,
    count: usize,
) -> Result<Scenario> {
    ensure!(
        count >= 4 && count.is_multiple_of(4),
        "--updates must be a positive multiple of four"
    );
    let quarter = count / 4;
    let mut queried = vec![false; rows];
    for posting in workload.postings.values() {
        for &id in posting {
            ensure!((id as usize) < rows, "posting outside base");
            queried[id as usize] = true;
        }
    }
    let ids: Vec<_> = queried
        .iter()
        .enumerate()
        .filter_map(|(id, &matches)| (!matches).then_some(id as u32))
        .take(quarter * 3)
        .collect();
    ensure!(
        ids.len() == quarter * 3,
        "not enough rows outside queried labels for this scenario"
    );
    let label = (0..=u32::MAX)
        .rev()
        .find(|label| !workload.postings.contains_key(label))
        .context("no unused probe label")?;
    ensure!(
        snapshot
            .search(&workload.queries[0].vector, label, 1, 1)?
            .hits
            .is_empty(),
        "probe label already exists in the index"
    );
    let mut mutations = Vec::with_capacity(count);
    let mut before = BTreeMap::new();
    let mut live = BTreeMap::new();
    let mut deleted = Vec::new();
    for (offset, &id) in ids.iter().enumerate() {
        let original = snapshot
            .get(id)?
            .context("selected base row does not exist")?;
        before.insert(id, original.clone());
        if offset < quarter * 2 {
            let vector = if offset < quarter {
                workload.queries[offset % workload.queries.len()]
                    .vector
                    .clone()
            } else {
                original.0
            };
            live.insert(id, vector.clone());
            mutations.push(Mutation::Upsert {
                id,
                vector,
                labels: vec![label],
            });
        } else {
            deleted.push(id);
            mutations.push(Mutation::Delete { id });
        }
    }
    for offset in 0..quarter {
        let id = u32::try_from(rows.checked_add(offset).context("insert ID overflow")?)?;
        ensure!(
            snapshot.get(id)?.is_none(),
            "insert scenario requires an original uncompacted index with dense IDs"
        );
        let vector = workload.queries[(offset + quarter) % workload.queries.len()]
            .vector
            .clone();
        live.insert(id, vector.clone());
        mutations.push(Mutation::Upsert {
            id,
            vector,
            labels: vec![label],
        });
    }
    Ok(Scenario {
        mutations,
        before,
        live,
        deleted,
        label,
        dimensions: workload.dimensions,
    })
}

fn verify_changed(
    snapshot: &FilteredSnapshot<u8>,
    scenario: &Scenario,
    sequence: u64,
    phase: &str,
    output: &mut File,
) -> Result<()> {
    ensure!(
        snapshot.sequence() == sequence,
        "unexpected lifecycle sequence"
    );
    for (&id, vector) in &scenario.live {
        let (found, labels) = snapshot.get(id)?.context("live changed record absent")?;
        ensure!(
            &found == vector && labels == [scenario.label],
            "changed vector/labels mismatch for {id}"
        );
    }
    for &id in &scenario.deleted {
        ensure!(
            snapshot.get(id)?.is_none(),
            "deleted record reappeared: {id}"
        );
    }
    let k = 10.min(scenario.live.len());
    let l = u32::try_from(scenario.live.len())?;
    let mut correct = 0;
    let mut fallbacks = 0;
    for vector in scenario.live.values() {
        let mut truth: Vec<_> = scenario
            .live
            .iter()
            .map(|(&id, value)| (exact_l2(vector, value), id))
            .collect();
        truth.sort_unstable();
        let expected: BTreeSet<_> = truth.iter().take(k).map(|(_, id)| *id).collect();
        let found = snapshot.search(vector, scenario.label, k, l)?;
        ensure!(
            found.sequence == sequence && found.hits.len() == k,
            "probe results incomplete"
        );
        let mut unique = BTreeSet::new();
        for hit in found.hits {
            ensure!(unique.insert(hit.id), "duplicate probe result");
            let stored = scenario
                .live
                .get(&hit.id)
                .context("probe returned a nonmatching record")?;
            ensure!(
                f64::from(hit.distance) == exact_l2(vector, stored) as f64,
                "probe distance differs from exact integer L2"
            );
            correct += usize::from(expected.contains(&hit.id));
        }
        fallbacks += usize::from(found.exact_fallback);
    }
    emit(
        output,
        json!({"kind":"probe","phase":phase,"sequence":sequence,"label":scenario.label,
        "live_records":scenario.live.len(),"deleted_records":scenario.deleted.len(),"queries":scenario.live.len(),
        "k":k,"l":l,"dimensions":scenario.dimensions,"recall":correct as f64/(scenario.live.len()*k) as f64,
        "truth":"independent_integer_squared_l2_then_stable_id","exact_fallback_queries":fallbacks,
        "point_record_checks":true,"filter_violations":0,"duplicate_results":0,"short_results":0}),
    )?;
    ensure!(
        correct == scenario.live.len() * k,
        "exhaustive-breadth probe differs from independent exact truth"
    );
    Ok(())
}

async fn exercise(
    mut index: FilteredIndex<u8>,
    root: &Path,
    rows: usize,
    workload: &Workload,
    args: &Args,
    output: &mut File,
    threads: usize,
) -> Result<()> {
    let old = index.snapshot();
    benchmark(&old, workload, args, "before_updates", output)?;
    let changes = scenario(&old, workload, rows, args.value("updates", "100").parse()?)?;
    let begin = Instant::now();
    let sequence = index.apply(&changes.mutations)?;
    emit(
        output,
        json!({"kind":"lifecycle","action":"apply","sequence":sequence,"mutations":changes.mutations.len(),
        "seconds":begin.elapsed().as_secs_f64(),"scope":"rows_outside_queried_natural_labels_plus_new_probe_label"}),
    )?;
    for (&id, expected) in &changes.before {
        ensure!(
            old.get(id)?.as_ref() == Some(expected),
            "old snapshot record changed"
        );
    }
    ensure!(
        old.search(&workload.queries[0].vector, changes.label, 1, 1)?
            .hits
            .is_empty(),
        "old snapshot sees new probe label"
    );
    let updated = index.snapshot();
    verify_changed(&updated, &changes, sequence, "after_updates", output)?;
    benchmark(&updated, workload, args, "after_updates", output)?;
    let begin = Instant::now();
    let generation = index.compact().await?;
    emit(
        output,
        json!({"kind":"lifecycle","action":"compact","generation":generation,
        "seconds":begin.elapsed().as_secs_f64()}),
    )?;
    // These leases still refer to the generations preceding compaction.
    verify_changed(
        &updated,
        &changes,
        sequence,
        "old_updated_snapshot_after_compact",
        output,
    )?;
    for (&id, expected) in &changes.before {
        ensure!(
            old.get(id)?.as_ref() == Some(expected),
            "pre-update snapshot changed after compact"
        );
    }
    let compacted = index.snapshot();
    verify_changed(&compacted, &changes, sequence, "after_compact", output)?;
    benchmark(&compacted, workload, args, "after_compact", output)?;
    drop((old, updated, compacted, index));
    let begin = Instant::now();
    index = FilteredIndex::open(root, threads)?;
    emit(
        output,
        json!({"kind":"lifecycle","action":"reopen","seconds":begin.elapsed().as_secs_f64(),"sequence":sequence}),
    )?;
    verify_changed(
        &index.snapshot(),
        &changes,
        sequence,
        "after_reopen",
        output,
    )?;
    benchmark(&index.snapshot(), workload, args, "after_reopen", output)?;
    let removed = index.collect_garbage()?;
    emit(
        output,
        json!({"kind":"lifecycle","action":"collect_garbage","removed":removed,
        "old_snapshots_consistent":true,"durable_reopen_verified":true}),
    )?;
    Ok(())
}

async fn run(args: Args) -> Result<()> {
    let root = args.required("root")?;
    let prepared = args.required("prepared")?;
    let out = args.required("out")?;
    if let Some(parent) = out.parent().filter(|path| !path.as_os_str().is_empty()) {
        std::fs::create_dir_all(parent)?;
    }
    let mut output = OpenOptions::new().create(true).append(true).open(out)?;
    let threads: usize = args.value("threads", "8").parse()?;
    ensure!(threads > 0, "--threads must be positive");
    let action = args.value("action", "all");
    ensure!(
        ["build", "query", "exercise", "all"].contains(&action.as_str()),
        "--action must be build,query,exercise,or all"
    );
    let (rows, dimensions) = header(&prepared.join("base.u8bin"))?;
    ensure!(
        rows > 0 && rows < u32::MAX as usize,
        "base rows must fit stable IDs"
    );
    emit(
        &mut output,
        json!({"kind":"experiment","action":action,"root":root,"prepared":prepared,
        "n_base":rows,"dimensions":dimensions,"index_threads":threads,"beam":4,"shared_cache_nodes":0,
        "storage":if cfg!(target_os="linux") {"native_io_uring"} else {"positional_pread"},
        "cache_bypass":true,"query_scheduling":"dynamic_one","warmup":"full_same_process_same_worker_count",
        "update_scope":"unqueried_natural_rows_and_fresh_label; supplied_natural_GT_remains_current"}),
    )?;
    let index = if action == "build" || action == "all" {
        let begin = Instant::now();
        let skip = args.value("skip-label", "200386");
        let skip = if skip == "none" {
            None
        } else {
            Some(skip.parse()?)
        };
        let postings = read_postings(&prepared.join("labels.txt"), rows, skip)?;
        let (read_rows, read_dimensions, vectors) = matrix_u8(&prepared.join("base.u8bin"))?;
        ensure!(
            (rows, dimensions) == (read_rows, read_dimensions),
            "base changed while loading"
        );
        let build = StitchedBuildConfig {
            label_degree: args.value("label-degree", "32").parse()?,
            max_degree: args.value("degree", "128").parse()?,
            l_build: args.value("build-l", "100").parse()?,
            alpha: args.value("alpha", "1.2").parse()?,
            concurrency: threads,
            seed: args.value("seed", "0").parse()?,
        };
        let config = FilteredIndexConfig {
            build,
            pq_chunks: args
                .value("pq-chunks", &dimensions.min(32).to_string())
                .parse()?,
            threads,
            delta_limits: DeltaLimits {
                max_records: args.value("delta-records", "10000").parse()?,
                max_bytes: args.value("delta-bytes", "67108864").parse()?,
            },
            ..Default::default()
        };
        let labels = postings.len();
        let memberships: usize = postings.values().map(Vec::len).sum();
        let recorded_config = json!({"label_degree":config.build.label_degree,"max_degree":config.build.max_degree,
            "l_build":config.build.l_build,"alpha":config.build.alpha,"seed":config.build.seed,
            "pq_chunks":config.pq_chunks,"max_delta_records":config.delta_limits.max_records,
            "max_delta_bytes":config.delta_limits.max_bytes});
        let index = FilteredIndex::build(
            &root,
            rowmajor::Ref::try_from_data(&vectors, rows, dimensions)
                .map_err(|error| anyhow::anyhow!(error.to_string()))?,
            postings,
            config,
        )
        .await?;
        emit(
            &mut output,
            json!({"kind":"build","implementation":"rust_native_lifecycle","rows":rows,
            "dimensions":dimensions,"labels":labels,"memberships":memberships,"skipped_label":skip,
            "threads":threads,"seconds_including_input_load":begin.elapsed().as_secs_f64(),"root":root,
            "config":recorded_config}),
        )?;
        index
    } else {
        FilteredIndex::open(&root, threads)?
    };
    if action == "build" {
        return Ok(());
    }
    let workload = load_workload(&prepared, args.value("limit", "2000").parse()?)?;
    ensure!(
        workload.dimensions == dimensions,
        "base/query dimensions differ"
    );
    if action == "query" {
        benchmark(&index.snapshot(), &workload, &args, "query", &mut output)
    } else {
        exercise(index, &root, rows, &workload, &args, &mut output, threads).await
    }
}

fn main() -> Result<()> {
    let args = Args::parse()?;
    let threads: usize = args.value("threads", "8").parse()?;
    ensure!(threads > 0, "--threads must be positive");
    tokio::runtime::Builder::new_multi_thread()
        .worker_threads(threads)
        .enable_all()
        .build()?
        .block_on(run(args))
}
